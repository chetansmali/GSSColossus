package com.example.votecasting;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class gallaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallary);
        Toast.makeText(getApplicationContext(),"this is gallary activity",Toast.LENGTH_LONG).show();
    }
}
