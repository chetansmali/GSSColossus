package com.example.votecasting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView tv1 = findViewById(R.id.heading);
        String text = "Already have an account? Sing in";

        SpannableString ss = new SpannableString(text);

        ForegroundColorSpan fcs = new ForegroundColorSpan(Color.RED);

        ss.setSpan(fcs,25,32, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv1.setText(ss);

        Button bt1 = findViewById(R.id.register);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent x = new Intent(MainActivity.this,login.class);
                startActivity(x);
            }
        });

        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent y = new Intent(MainActivity.this,login.class);
                startActivity(y);
            }
        });
    }
}
